<nav class="navbar sticky-top navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#"><img src="<?php echo e(asset('img/logo.png')); ?>" class="logo"></a>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      
      <div class="navbar-nav">
        <?php if(auth()->guard()->guest()): ?>
          <a class="nav-item nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Inicio <span class="sr-only">(current)</span></a>
          <a class="nav-item nav-link <?php echo e(Request::is('quienes-somos') ? 'active' : ''); ?>" href="<?php echo e(route('quienes')); ?>">¿Quiénes Somos?</a>
          <a class="nav-item nav-link <?php echo e(Request::is('como-funciona') ? 'active' : ''); ?>" href="<?php echo e(url('como-funciona')); ?>">¿Cómo Funciona?</a>
          <a class="nav-item nav-link <?php echo e(Request::is('precios') ? 'active' : ''); ?>" href="<?php echo e(url('/precios')); ?>">Precios</a>
          <a class="nav-item nav-link <?php echo e(Request::is('login') ? 'active' : ''); ?>" href="<?php echo e(route('login')); ?>">Iniciar Sesión</a>
          <a class="nav-item nav-link" href="<?php echo e(route('register')); ?>"><span class="badge badge-secondary p-2"><i class="fas fa-glass-cheers"></i> Crear Evento Gratis</span></a>
        <?php else: ?>
          <a class="nav-item nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Panel de Control</a>
          <a class="nav-item nav-link" href="https://www.kichink.com/stores/kutsu" target="_blank">Comprar Códigos</a>
          <li class="nav-item dropdown">
            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
              <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <?php echo e(__('Salir')); ?>

              </a>
              <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
              </form>
            </div>
          </li>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>