<?php $__env->startSection('titulo','Panel de Control de tu Evento'); ?>
<?php $__env->startSection('contenido'); ?>
		<section class="row">
			<?php if (\Shinobi::can('eventos.create')): ?>
				<article class="col-md-2">
					<?php echo Form::open(['route'=>'eventos.validateCode','mehtod'=>'post']); ?>

						<div class="form-group">
							<?php echo Form::label('codigo','Nuevo Evento:'); ?>

							<?php echo Form::text('codigo',null,['class'=>'form-control','placeholder'=>'Ingresa tu codigo','autofocus','required']); ?>

						</div>
						<div class="form-group">
							<?php echo Form::submit('Validar',['class'=>'btn btn-success float-right']); ?>

						</div>

					<?php echo Form::close(); ?>

				</article>
			<?php endif; ?>
				<?php if(empty($user->evento)): ?>
				<?php else: ?>
					<article class="col-md-10 boda">
						<?php switch($user->evento->tipo_evento_id):
							case (1): ?>
								<h2>Nuestra Boda</h2>
								<h3 class="text-center">
									<?php echo e($user->name); ?>

									<?php if(empty($user->evento->cofestejado)): ?>
										</h3>
										<div class="d-flex justify-content-center">
											<?php echo $__env->make('eventos.addNovio', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
										</div>
									<?php else: ?>
										<span>&</span> <?php echo e($user->evento->cofestejado); ?> </h3>
									<?php endif; ?>
							<?php break; ?>
							<?php case (2): ?>
								<h2>Mis XV Años</h2>
								<h3 class="text-center">
									<?php echo e($user->name); ?>

								</h3>
							<?php break; ?>
						<?php endswitch; ?>
						<hr>
						<p class="text-center"><?php echo e(Date::parse($user->evento->fecha)->format('l j \d\e F \d\e Y')); ?></p>
						<hr>
						<p class="text-center">
							<a href="<?php echo e(route('eventos.show',$user->evento->id)); ?>" class="btn btn-outline-dark">Ver Detalles...</a>
						</p>
					</article>
				<?php endif; ?>

				
		</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>