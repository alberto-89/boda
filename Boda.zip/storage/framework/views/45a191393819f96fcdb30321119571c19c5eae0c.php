<?php $__env->startSection('titulo','Administrar Planes'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="row pt-3">
	<article class="col-md-9">
		<table class="table text-center">
			<thead class="thead-dark">
				<tr>
					<th>Plan</th>
					<th>Invitados</th>
					<th>Descripción</th>
					<th>Precio</th>
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($plan->nombre); ?></td>
						<td><?php echo e($plan->invitados); ?></td>
						<td><?php echo e($plan->descripcion); ?></td>
						<td><?php echo e($plan->precio); ?></td>
						<td>
							<a href="<?php echo e(route('planes.edit',$plan->id)); ?>" class="btn btn-outline-info">
								<i class="fas fa-edit"></i>
							</a>
						</td>
						<td>
							<a href="<?php echo e(route('planes.destroy',$plan->id)); ?>" class="btn btn-outline-danger">
								<i class="fas fa-trash-alt"></i>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</article>
	<article class="col-md-3">
		<?php echo Form::open(['route'=>'planes.store','method'=>'post']); ?>

			<div class="form-group">
				<?php echo Form::label('nombre','Nombre:'); ?>

				<?php echo Form::text('nombre',null,['class'=>'form-control','autofocus','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('invitados','Invitados:'); ?>

				<?php echo Form::text('invitados',null,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('precio','Precio:'); ?>

				<?php echo Form::text('precio',null,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('descripcion','Descripción:'); ?>

				<?php echo Form::textarea('descripcion',null,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::submit('Agregar',['class'=>'btn btn-success']); ?>

			</div>
		<?php echo Form::close(); ?>

	</article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>