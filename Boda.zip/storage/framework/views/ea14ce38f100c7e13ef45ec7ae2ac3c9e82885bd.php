<?php $__env->startSection('titulo','Bienvedio'); ?>
<?php $__env->startSection('portada'); ?>
<header class="container-fluid dashCover d-flex align-items-center justify-content-center">
    <?php if (\Shinobi::can('clientes.index')): ?>
        <article>
            <a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-outline-light btn-center">Panel de Control</a>
        </article>
    <?php endif; ?>
    <?php if (\Shinobi::can('admin.index')): ?>
        <article>
            <a href="<?php echo e(route('admin.index')); ?>" class="btn btn-outline-light btn-center">Panel de Control Admin</a>
        </article>
    <?php endif; ?>
</header>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>