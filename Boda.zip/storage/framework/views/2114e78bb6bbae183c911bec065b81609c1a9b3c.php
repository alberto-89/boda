<?php $__env->startSection('titulo',$evento->tipoEvento->tipo.' de '.Auth::User()->name); ?>
<?php $__env->startSection('contenido'); ?>
	<article class="text-center">
		<h1>
			La <?php echo e($evento->tipoEvento->tipo); ?> de <?php echo e(Auth::User()->name); ?>

			<?php if(empty($evento->cofestejado)): ?>
			<?php else: ?>
			y <?php echo e($evento->cofestejado); ?>

			<?php endif; ?>
		</h1>
		<p class="text-center"><?php echo e(Date::parse($evento->fecha)->format('l j \d\e F \d\e Y')); ?></p>
	</article>
	<section class="row">
		<article class="col-md-4">
			<i class="far fa-smile faces float-left mr-2 green"></i>
			<div>
				<h2><?php echo e($asistira); ?></h2>
					<h2>Aceptaron</h2>
			</div>
		</article>
		<article class="col-md-4">
			<i class="far fa-meh faces float-left mr-2 yellow"></i>
			<div>
				<h2><?php echo e($duda); ?></h2>
				<h2>Estan indecisos</h2>
			</div>
		</article>
		<article class="col-md-4">
			<i class="far fa-frown faces float-left mr-2 red"></i>
			<div>
				<h2><?php echo e($noAsistira); ?></h2>
				<h2>No Asistiran</h2>
			</div>
		</article>
	</section>
	<hr>
	<article class="row">
		<div class="col-md-5">
			<h3>Lista de Invitados</h3>
		</div>
		<div class="col-md-7 text-right">
			<?php if($evento->confirmado === 0): ?>
				<a href="<?php echo e(route('eventos.definitiveGuest',$evento->id)); ?>" class="btn btn-success"><i class="far fa-check-circle"></i> Lista Definitiva</a>
				<?php if($totalInvitados < Session::get('plan')): ?>
					<?php if (\Shinobi::can('invitados.create')): ?>
						<a href="<?php echo e(route('invitados.create')); ?>" class="btn btn-outline-dark"><i class="fas fa-user-plus"></i> Agregar Invitado</a>
					<?php endif; ?>
				<?php else: ?>
					<a href="" class="btn btn-outline-info">¿Necesitas más invitados?</a>
				<?php endif; ?>
			<?php endif; ?>
			<a href="<?php echo e(route('pdf.reporte')); ?>" class="btn btn-outline-dark"><i class="fas fa-download"></i> Descargar Lista</a>
			<button type="button" class="btn btn-primary">
			  Invitados <span class="badge badge-light"><?php echo e($totalInvitados); ?></span>
			</button>
		</div>
	</article>
	<hr>
	
	<table class="table table-striped">
		<thead class="thead-dark">
			<tr>
				<th>Fecha de Confirmación</th>
				<?php if($evento->confirmado === 0): ?>
					<th><i class="fas fa-trash-alt"></i></th>
				<?php endif; ?>
				<th>Nombre</th>
				<th>Acompañantes</th>
				<th>Correo Electronico</th>
				<th>Telefono</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $evento->invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td>
						<?php if(empty($invitado->confirmacion)): ?>
							Sin Confirmar
						<?php else: ?>
							<?php echo e(Date::parse($invitado->confirmacion->created_at)->format('l j \d\e F \d\e Y')); ?>

						<?php endif; ?>
					</td>
					<?php if($evento->confirmado === 0): ?>
						<td>
							<a href="<?php echo e(route('invitados.destroy',$invitado->id)); ?>" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash-alt"></i></a>
						</td>
					<?php endif; ?>
					<td>
						<a href="<?php echo e(route('invitados.show',$invitado->id)); ?>">
							<?php echo e($invitado->name.' '.$invitado->appat.' '.$invitado->apmat); ?>

						</a>
					</td>
					<td class="text-center"><?php echo e($invitado->acompanantes->count()); ?></td>
					<td><?php echo e($invitado->email); ?></td>
					<td><?php echo e($invitado->telefono); ?></td>
					<td class="text-center"><?php if(empty($invitado->confirmacion)): ?>
							<b><i class="fas fa-question"></i></b>
						<?php else: ?>
							<?php switch($invitado->confirmacion->asistencia->id):
								case (1): ?>
									<i class="far fa-smile green"></i>
								<?php break; ?>
								<?php case (2): ?>
									<i class="far fa-meh yellow"></i>
								<?php break; ?>
								<?php case (3): ?>
									<i class="far fa-frown red"></i>
								<?php break; ?>
							<?php endswitch; ?>
							<?php echo e($invitado->confirmacion->asistencia->tipo); ?>

						<?php endif; ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>