<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>">
    <title><?php echo $__env->yieldContent('titulo'); ?> | RVSP</title>
  </head>
  <body>
    <?php echo $__env->make('templetes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('welcome'); ?>
    <?php echo $__env->yieldContent('portada'); ?>
      <section class="container <?php echo e(Request::is(['home','confirmar']) ? '' : 'pt-3 pb-3'); ?>">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
<?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('contenido'); ?>
      </section>
    <footer>
      <section class="container">
        <section class="row">
          <article class="col-md-3 mb-1">
            <h5>Contáctanos</h5>
            <hr>
            <small>
              <ul class="list-group list-group-flush">
                <li><span>Correo:</span> hola@boda.com</li>
                <li><span>Telefono:</span> +52 (993) 366 8855</li>
                <li><span>Villahermosa, Tabasco, México</span></li>
              </ul>
            </small>
          </article>
          <article class="col-md-3 mb-1">
            <h5>Síguenos</h5>
            <hr>
            <a href="">
              <img src="<?php echo e(asset('img/facebook.png')); ?>" alt="www.facebook.com">
            </a>
            <a href="">
              <img src="<?php echo e(asset('img/instagram.png')); ?>" alt="www.instagram.com">
            </a>
          </article>
          <article class="col-md-3 mb-1">
            <h5>Suscríbete</h5>
            <hr>
            <?php echo Form::open(); ?>

                <p><small>Recibe todas las noticias, promociones y publicaciones de nuestro blog directo a tu correo electrónico</small></p>
              <?php echo Form::label('email','Correo Electrónico'); ?>

              <?php echo Form::email('email',null,['class'=>'form-control','placeholder'=>'usuario@ejemplo.com','required'] ); ?>

              <?php echo Form::submit('Registrame',['class'=>'btn btn-sm  btn-light float-right mt-1']); ?>

            <?php echo Form::close(); ?>

          </article>
          <article class="col-md-3 mb-1">
            <h5>Cosas Importantes</h5>
            <hr>
            <small>
              <ul class="list-group list-group-flush">
                <li>Aviso de Privacidad</li>
                <li>Terminos y Condiciones</li>
                <li>Nuestro Equipo</li>
                <li>FAQ</li>
              </ul>
            </small>
          </article>
        </section>
      </section>
      <section class="footer">
        <div class="col-md-12">
          <small><p class="text-center">2019 bodarevsp.com</p></small>
        </div>
      </section>
    </footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo e(asset('js/jquery-3.3.1.slim.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  </body>
</html>