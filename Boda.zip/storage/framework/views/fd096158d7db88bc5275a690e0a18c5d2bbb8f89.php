<?php $__env->startSection('titulo','Administrar Tipode Eventos'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="row pt-3">
	<article class="col-md-6">
		<?php echo Form::open(['route'=>['tipoEventos.update',$tipo->id],'method'=>'put']); ?>

			<div class="form-group">
				<?php echo Form::label('tipo','Tipo de Evento:'); ?>

				<?php echo Form::text('tipo',$tipo->tipo,['class'=>'form-control','autofocus','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('descripcion','Descripción de Evento:'); ?>

				<?php echo Form::textarea('descripcion',$tipo->descripcion,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::submit('Agregar',['class'=>'btn btn-success']); ?>

				<a href="<?php echo e(route('tipoEventos.index')); ?>" class="btn btn-danger">Cancelar</a>
			</div>
		<?php echo Form::close(); ?>

	</article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>