<?php $__env->startSection('titulo','Editar Tipode de Mesas'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="row pt-3">
	<article class="col-md-8">
		<table class="table text-center">
			<thead class="thead-dark">
				<tr>
					<th>Tipo</th>
					<th>Capacidad</th>
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php echo e($tipo->tipo); ?></td>
					<td><?php echo e($tipo->capacidad); ?></td>
					<td>
						<a href="<?php echo e(route('tipomesas.edit',$tipo->id)); ?>" class="btn btn-outline-info">
							<i class="fas fa-edit"></i>
						</a>
					</td>
					<td>
						<a href="<?php echo e(route('tipomesas.destroy',$tipo->id)); ?>" class="btn btn-outline-danger">
							<i class="fas fa-trash-alt"></i>
						</a>
					</td>
				</tr>
			</tbody>
		</table>
	</article>
	<article class="col-md-4">
		<?php echo Form::open(['route'=>['tipomesas.update',$tipo->id],'method'=>'put']); ?>

			<div class="form-group">
				<?php echo Form::label('tipo','Tipo de Mesa:'); ?>

				<?php echo Form::text('tipo',$tipo->tipo,['class'=>'form-control','autofocus','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('capacidad','Capacidad de la Mesa:'); ?>

				<?php echo Form::text('capacidad',$tipo->capacidad,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::submit('Agregar',['class'=>'btn btn-success']); ?>

			</div>
		<?php echo Form::close(); ?>

	</article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>