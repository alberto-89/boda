<?php $__env->startSection('titulo','Evento Nuevo'); ?>
<?php $__env->startSection('contenido'); ?>
		<section class="row">
			<div class="col-md-6 bodaBacground d-flex align-items-center justify-content-center">
				<h2 class="eventoBoda text-center">Nuestra Boda</h2>
			</div>
			<div class="col-md-6">
				<div class="card">
				  <div class="card-body">
				    <?php echo Form::open(['route'=>'eventos.store', 'method'=>'post']); ?>

				    	<?php echo Form::hidden('tipo_evento_id',1); ?>

						<div class="form-group">
						  	<?php echo Form::label('lugar','¿Dónde será tu evento?'); ?>

						  	<?php echo Form::text('lugar', null, ['class'=>'form-control', 'placeholder'=>'Gran Salón'], 'required', 'autofocus'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('direccion','¿Cúal es la dirección?'); ?>

						  	<?php echo Form::text('direccion', null, ['class'=>'form-control', 'placeholder'=>'Av. Principal 345 Col. Centro'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('fecha','¿Cúando será tu evento?'); ?>

						  	<?php echo Form::date('fecha', null, ['class'=>'form-control'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('hora','¿A que hora será tu evento?'); ?>

						  	<?php echo Form::time('hora', null, ['class'=>'form-control'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('vestimenta','¿Tienes algun tipo de vestimenta para tu evento?'); ?>

						  	<?php echo Form::text('vestimenta', null, ['class'=>'form-control', 'placeholder'=>'Formal ó Casual, etc..'], 'required'); ?>

						 </div>
						 <div class="form-group">
						 	<?php echo Form::submit('Crear', ['class'=>'btn btn-success']); ?>

						 	<a href="#" class="btn btn-danger">Cancelar</a>
						 </div>
					<?php echo Form::close(); ?>

				  </div>
				</div>
			</div>
		</section>
		<hr>
		<section class="row mt-3">
			<div class="col-md-6 xvBacground d-flex align-items-center justify-content-center">
				<h2 class="eventoXV text-center">Mis XV Años</h2>
			</div>
			<div class="col-md-6">
				<div class="card">
				  <div class="card-body">
				    <?php echo Form::open(['route'=>'eventos.store', 'method'=>'post']); ?>

				    	<?php echo Form::hidden('tipo_evento_id',1); ?>

						<div class="form-group">
						  	<?php echo Form::label('lugar','¿Dónde será tu evento?'); ?>

						  	<?php echo Form::text('lugar', null, ['class'=>'form-control', 'placeholder'=>'Gran Salón'], 'required', 'autofocus'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('direccion','¿Cúal es la dirección?'); ?>

						  	<?php echo Form::text('direccion', null, ['class'=>'form-control', 'placeholder'=>'Av. Principal 345 Col. Centro'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('fecha','¿Cúando será tu evento?'); ?>

						  	<?php echo Form::date('fecha', null, ['class'=>'form-control'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('hora','¿A que hora será tu evento?'); ?>

						  	<?php echo Form::time('hora', null, ['class'=>'form-control'], 'required'); ?>

						 </div>
						 <div class="form-group">
						  	<?php echo Form::label('vestimenta','¿Tienes algun tipo de vestimenta para tu evento?'); ?>

						  	<?php echo Form::text('vestimenta', null, ['class'=>'form-control', 'placeholder'=>'Formal ó Casual, etc..'], 'required'); ?>

						 </div>
						 <div class="form-group">
						 	<?php echo Form::submit('Crear', ['class'=>'btn btn-success']); ?>

						 	<a href="#" class="btn btn-danger">Cancelar</a>
						 </div>
					<?php echo Form::close(); ?>

				  </div>
				</div>
			</div>
		</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>