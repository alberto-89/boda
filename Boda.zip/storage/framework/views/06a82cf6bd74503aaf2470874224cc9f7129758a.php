<?php $__env->startSection('titulo','Confirmar Asistencia'); ?>
<?php $__env->startSection('portada'); ?>
<header class="container-fluid dashCover d-flex align-items-center justify-content-center">
    <section class="col-md-4 confirmar">
			<h1 class="text-center">Confirma tu Asistencia</h1>
			<hr>
			<?php echo Form::open(['route'=>'confirmaciones.show','method'=>'get']); ?>

				<div class="form-group">
					<?php echo Form::label('codigo','Ingresa el Codigo:'); ?>

					<?php echo Form::text('codigo',null,['class'=>'form-control','placeholder'=>'Codigo','required','autofocus']); ?>

				</div>
				<div class="form-group">
					<?php echo Form::submit('Confirmar',['class'=>'btn btn-success']); ?>

				</div>
			<?php echo Form::close(); ?>

		</section>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>