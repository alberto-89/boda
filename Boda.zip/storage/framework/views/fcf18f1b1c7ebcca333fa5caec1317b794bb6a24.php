<?php $__env->startSection('titulo','Agregar Invitado'); ?>
<?php $__env->startSection('contenido'); ?>
	<div class="col-md-6">
		<?php echo Form::open(['route'=>'invitados.store','method'=>'post']); ?>

			<div class="form-group">
				<div class="custom-control custom-radio custom-control-inline">
				  <input type="radio" id="titulo1" name="titulo" class="custom-control-input" value="Sr.">
				  <label class="custom-control-label" for="titulo1">Sr.</label>
				</div>
				<div class="custom-control custom-radio custom-control-inline">
				  <input type="radio" id="titulo2" name="titulo" class="custom-control-input" value="Sra.">
				  <label class="custom-control-label" for="titulo2">Sra.</label>
				</div>
				<div class="custom-control custom-radio custom-control-inline">
				  <input type="radio" id="titulo3" name="titulo" class="custom-control-input" value="Srita.">
				  <label class="custom-control-label" for="titulo3">Srita.</label>
				</div>
				<div class="custom-control custom-radio custom-control-inline">
				  <input type="radio" id="titulo4" name="titulo" class="custom-control-input" value="Joven">
				  <label class="custom-control-label" for="titulo4">Joven</label>
				</div>
			</div>
			<div class="form-group">
				<?php echo Form::label('name','Nombre:'); ?>

				<?php echo Form::text('name',null,['class'=>'form-control','required','autofocus']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('appat','Apellido Paterno'); ?>

				<?php echo Form::text('appat',null,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('apmat','Apellido Materno'); ?>

				<?php echo Form::text('apmat',null,['class'=>'form-control']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('telefono','Telefono'); ?>

				<?php echo Form::text('telefono',null,['class'=>'form-control']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('email','Correo Electronico'); ?>

				<?php echo Form::email('email',null,['class'=>'form-control']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::submit('Registrar',['class'=>'btn btn-success']); ?>

				<a href="<?php echo e(route('clientes.index')); ?>" class="btn btn-danger">Cancelar</a>
			</div>
		<?php echo Form::close(); ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>