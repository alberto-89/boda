<?php $__env->startSection('titulo','Panel de Control de Administrador'); ?>
<?php $__env->startSection('contenido'); ?>
		<section class="row pt-3">
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Usuarios</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="#" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Tipo de Eventos</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="<?php echo e(route('tipoEventos.index')); ?>" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Planes</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="<?php echo e(route('planes.index')); ?>" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Códigos</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="<?php echo e(route('codigos.index')); ?>" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Tipo de Mesas</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="<?php echo e(route('tipomesas.index')); ?>" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
			<div class="col-md-4 pb-3">
				<div class="card" style="width: 18rem;">
				  <div class="card-body">
				    <h5 class="card-title">Tipo de Asistencias</h5>
				    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
				    <a href="<?php echo e(route('asistencias.index')); ?>" class="btn btn-dark">¡Ir!</a>
				  </div>
				</div>
			</div>
		</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>