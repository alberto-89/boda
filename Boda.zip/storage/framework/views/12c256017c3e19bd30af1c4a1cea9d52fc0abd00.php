<?php $__env->startSection('titulo','¿Cómo Funciona?'); ?>
<?php $__env->startSection('contenido'); ?>
  <section class="row">
    <header class="col-md-12">
      <h3>¿Cómo Funciona?</h3>
      <hr>
    </header>
    <article class="col-md-3">
     <h2 class="text-center">Registra</h2>
     <hr>
     <p class="text-justify">
        <p class="text-center">
          <i class="fas fa-user faces rosa"></i>
        </p>
        Rellena un simple formulario para ingresar al sistema
      </p>
    </article>
    <article class="col-md-3">
      <h2 class="text-center">Crea</h2>
      <hr>
      <p class="text-center">
        <i class="fas fa-plus-circle faces rosa"></i>
      </p>
      <p class="text-justify">
        Crea tu evento con los invitados que necesitas
      </p>
    </article>
    <article class="col-md-3">
      <h2 class="text-center">Confirma</h2>
      <hr>
      <p class="text-center">
        <i class="fas fa-check-double faces rosa"></i>
      </p>
      <p class="text-justify">
        Nosotros hacemos las llamadas por ti
      </p>
    </article>
    <article class="col-md-3">
      <h2 class="text-center">¿Y tus invitados?</h2>
      <hr>
      <p class="text-center">
        <i class="fas fa-users faces green"></i>
      </p>
        <p class="text-justify">
        Ellos pueden hacer su confirmación en linea en el momento que lo deseen
      </p>
    </article>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>