<?php $__env->startSection('titulo','Administrar Planes'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="row pt-3">
	<article class="col-md-9">
		<table class="table text-center">
			<thead class="thead-dark">
				<tr>
					<th>Plan</th>
					<th>Invitados</th>
					<th>Descripción</th>
					<th>Precio</th>
					<th colspan="2">Acciones</th>
				</tr>
			</thead>
			<tbody>
				<tr>
						<td><?php echo e($plan->nombre); ?></td>
						<td><?php echo e($plan->invitados); ?></td>
						<td><?php echo e($plan->descripcion); ?></td>
						<td><?php echo e($plan->precio); ?></td>
						<td>
							<a href="<?php echo e(route('planes.edit',$plan->id)); ?>" class="btn btn-outline-info">
								<i class="fas fa-edit"></i>
							</a>
						</td>
						<td>
							<a href="<?php echo e(route('planes.destroy',$plan->id)); ?>" class="btn btn-outline-danger">
								<i class="fas fa-trash-alt"></i>
							</a>
						</td>
					</tr>
			</tbody>
		</table>
	</article>
	<article class="col-md-3">
		<h3>Editar</h3>
		<?php echo Form::open(['route'=>['planes.update',$plan->id],'method'=>'put']); ?>

			<div class="form-group">
				<?php echo Form::label('nombre','Nombre:'); ?>

				<?php echo Form::text('nombre',$plan->nombre,['class'=>'form-control','autofocus','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('invitados','Invitados:'); ?>

				<?php echo Form::text('invitados',$plan->invitados,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('precio','Precio:'); ?>

				<?php echo Form::text('precio',$plan->precio,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::label('descripcion','Descripción:'); ?>

				<?php echo Form::textarea('descripcion',$plan->descripcion,['class'=>'form-control','required']); ?>

			</div>
			<div class="form-group">
				<?php echo Form::submit('Agregar',['class'=>'btn btn-success']); ?>

				<a href="<?php echo e(route('planes.index')); ?>" class="btn btn-danger">
					Cancelar
				</a>
			</div>
		<?php echo Form::close(); ?>

	</article>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>