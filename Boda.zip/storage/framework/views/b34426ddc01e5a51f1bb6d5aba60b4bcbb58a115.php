<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Repore</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<article class="text-center">
		<h1>
			La <?php echo e($evento->tipoEvento->tipo); ?> de <?php echo e(Auth::User()->name); ?>

			<?php if(empty($evento->cofestejado)): ?>
			<?php else: ?>
			y <?php echo e($evento->cofestejado); ?>

			<?php endif; ?>
		</h1>
		<p class="text-center"><?php echo e(Date::parse($evento->fecha)->format('l j \d\e F \d\e Y')); ?></p>
	</article>
	<table class="table table-striped table-sm">
		<thead class="thead-dark">
			<tr>
				<th>Nombre</th>
				<th>Acompañantes</th>
				<th>Status</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $evento->invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(empty($invitado->confirmacion)): ?>
					<tr>
						<td><?php echo e($invitado->name." ".$invitado->appat." ".$invitado->apmat); ?></td>
						<td><?php echo e($invitado->acompanantes->count()); ?></td>
						<td>Sin Confirmar</b></td>
					</tr>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $evento->invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if(empty($invitado->confirmacion)): ?>
				<?php else: ?>
				<?php if($invitado->confirmacion->asistencia->id == 1): ?>
					<tr>
						<td><?php echo e($invitado->name." ".$invitado->appat." ".$invitado->apmat); ?></td>
						<td><?php echo e($invitado->acompanantes->count()); ?></td>
						<td>Asistirá</td>
					</tr>
				<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $evento->invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(empty($invitado->confirmacion)): ?>
				<?php else: ?>
				<?php if($invitado->confirmacion->asistencia->id == 2): ?>
					<tr>
						<td><?php echo e($invitado->name." ".$invitado->appat." ".$invitado->apmat); ?></td>
						<td><?php echo e($invitado->acompanantes->count()); ?></td>
						<td>Lo está pensando</td>
					</tr>
				<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $evento->invitados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invitado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if(empty($invitado->confirmacion)): ?>
				<?php else: ?>
				<?php if($invitado->confirmacion->asistencia->id == 3): ?>
					<tr>
						<td><?php echo e($invitado->name." ".$invitado->appat." ".$invitado->apmat); ?></td>
						<td><?php echo e($invitado->acompanantes->count()); ?></td>
						<td><i class="far fa-frown red"></i> No Asistirá</td>
					</tr>
				<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html>