<?php $__env->startSection('titulo','Confirmar Asistencia'); ?>
<?php $__env->startSection('contenido'); ?>
	<section class="row">
		<article class="col-md-6">
			<?php echo Form::open(['route'=>'confirmaciones.store','method'=>'post']); ?>

			<table class="table table-striped">
				<thead class="thead-dark">
					<tr>
						<th colspan="2" class="text-center">Invitado</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Nombre:</td>
						<td><b><?php echo e($invitado->titulo.' '.$invitado->name); ?></b></td>
					</tr>
					<tr>
						<td>Apellidos:</td>
						<td><?php echo e($invitado->appat.' '.$invitado->apmat); ?></td>
					</tr>
					<tr>
						<td>Teléfono:</td>
						<td><?php echo e($invitado->telefono); ?></td>
					</tr>
					<tr>
						<td>Correo:</td>
						<td><?php echo e($invitado->email); ?></td>
					</tr>
					<tr>
						<td>Codigo:</td>
						<td><?php echo e($invitado->codigo); ?></td>
					</tr>
					<tr>
						<td>
							<?php if($invitado->acompanantes->count() == 1): ?>
								Acompañante:
							<?php else: ?>
								Acompañantes:
							<?php endif; ?>
						</td>
						<td><?php echo e($invitado->acompanantes->count()); ?></td>
					</tr>
				</tbody>
			</table>
		</article>
		<article class="col-md-6">
			<table class="table table-striped">
				<thead class="thead-dark">
					<tr>
						<th colspan="2" class="text-center">
							<?php if($invitado->acompanantes->count() == 1): ?>
								Acompañante
							<?php else: ?>
								Acompañantes
							<?php endif; ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<tr class="text-center">
						<td colspan="2"><small><b>Desliza para confirmar</b></small></td>
					</tr>
					<?php $__currentLoopData = $invitado->acompanantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acompanante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<div class="custom-control custom-switch">
								  <input type="checkbox" class="custom-control-input" id="customSwitch<?php echo e($acompanante->id); ?>" name="invitados[]" value="<?php echo e($acompanante->id); ?>">
								  <label class="custom-control-label" for="customSwitch<?php echo e($acompanante->id); ?>"><?php echo e($acompanante->name.' '.$acompanante->appat.' '.$acompanante->apmat); ?></label>
								</div>
							</td>
							<td>
								<?php if($acompanante->nino == 1): ?>
									<i class="fas fa-child green"></i> Niño
								<?php else: ?>
									<i class="fas fa-user red"></i> Adulto
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			<hr>
			<div class="btn-group btn-group-toggle" data-toggle="buttons">
			  <label class="btn btn-outline-success active">
			    <input type="radio" name="asistencia" id="option1" autocomplete="off" value="1" checked> Asistiré
			  </label>
			  <label class="btn btn-outline-dark">
			    <input type="radio" name="asistencia" id="option2" autocomplete="off" value="2"> Lo estoy pensando
			  </label>
			  <label class="btn btn-outline-danger">
			    <input type="radio" name="asistencia" id="option3" autocomplete="off" value="3"> No asistiré
			  </label>
			</div>
			<?php echo Form::submit('Confirmar Asistencia',['class'=>'btn btn-info float-right']); ?>

			<?php echo Form::close(); ?>

		</article>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templetes.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>